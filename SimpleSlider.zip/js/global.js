// JavaScript Document

$(function() {
	$('#slider-1 ul').simpleslider();
	
	$('#slider-2 ul').simpleslider({
		speed			: 300,
		easing			: 'swing'
	});
	
	$('#slider-3 ul').simpleslider({
		speed			: 1300,
		easing			: 'easeOutBounce',
		prevText		: 'PREV',
		nextText		: 'NEXT'
	});
	
	$('#slider-4 div').simpleslider({
		speed			: 500,
		transition		: 'fade',
		auto			: true,
		navigation		: false
	});
	
	$('#slider-5 ol').simpleslider({
		transition		: 'cut',
		navigation		: false,
		prevText		: '-',
		nextText		: '+',
		loop			: false
	});
});